package com.gominolandia;

import com.gominolandia.block.ModBlocks;
import com.gominolandia.item.ModCreativeTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(GominolandiaMod.MOD_ID)
public class GominolandiaMod {
    public static final String MOD_ID = "gominolandia";

    public GominolandiaMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModBlocks.ITEMS.register(bus);
        ModCreativeTabs.TABS.register(bus);
    }
}
