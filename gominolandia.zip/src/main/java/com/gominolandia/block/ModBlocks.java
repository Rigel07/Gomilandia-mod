package com.gominolandia.block;

import com.gominolandia.GominolandiaMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HalfTransparentBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, GominolandiaMod.MOD_ID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GominolandiaMod.MOD_ID);
    /** Todos los bloques del mod (para la pestana creativa). */
    public static final List<RegistryObject<Block>> ALL = new ArrayList<>();

    private static RegistryObject<Block> reg(String name, Supplier<Block> supplier) {
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        ALL.add(block);
        return block;
    }

    private static BlockBehaviour.Properties leaves(MapColor color) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(0.2F).sound(SoundType.WOOL)
                .noOcclusion().lightLevel(s -> 5)
                .isValidSpawn((s, g, p, e) -> false)
                .isSuffocating((s, g, p) -> false).isViewBlocking((s, g, p) -> false);
    }

    private static BlockBehaviour.Properties gummy(MapColor color) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(0.4F).sound(SoundType.HONEY_BLOCK)
                .noOcclusion().lightLevel(s -> 4)
                .isValidSpawn((s, g, p, e) -> false)
                .isSuffocating((s, g, p) -> false).isViewBlocking((s, g, p) -> false);
    }

    private static BlockBehaviour.Properties solid(MapColor color, float strength, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(strength).sound(sound);
    }

    // --- terreno
    public static final RegistryObject<Block> GUMMY_GRASS = reg("gummy_grass",
            () -> new Block(solid(MapColor.COLOR_LIGHT_GREEN, 0.6F, SoundType.HONEY_BLOCK)));
    public static final RegistryObject<Block> CARAMEL_DIRT = reg("caramel_dirt",
            () -> new Block(solid(MapColor.COLOR_ORANGE, 0.5F, SoundType.GRAVEL)));

    // --- arboles de algodon de azucar
    public static final RegistryObject<Block> CANDY_LOG = reg("candy_log",
            () -> new RotatedPillarBlock(solid(MapColor.COLOR_RED, 1.5F, SoundType.WOOD)));
    public static final RegistryObject<Block> COTTON_CANDY_PINK = reg("cotton_candy_leaves_pink",
            () -> new HalfTransparentBlock(leaves(MapColor.COLOR_PINK)));
    public static final RegistryObject<Block> COTTON_CANDY_BLUE = reg("cotton_candy_leaves_blue",
            () -> new HalfTransparentBlock(leaves(MapColor.COLOR_LIGHT_BLUE)));
    public static final RegistryObject<Block> COTTON_CANDY_LILAC = reg("cotton_candy_leaves_lilac",
            () -> new HalfTransparentBlock(leaves(MapColor.COLOR_PURPLE)));

    // --- gominolas
    public static final RegistryObject<Block> GUMMY_RED = reg("gummy_red", () -> new GummyBlock(gummy(MapColor.COLOR_RED)));
    public static final RegistryObject<Block> GUMMY_ORANGE = reg("gummy_orange", () -> new GummyBlock(gummy(MapColor.COLOR_ORANGE)));
    public static final RegistryObject<Block> GUMMY_YELLOW = reg("gummy_yellow", () -> new GummyBlock(gummy(MapColor.COLOR_YELLOW)));
    public static final RegistryObject<Block> GUMMY_GREEN = reg("gummy_green", () -> new GummyBlock(gummy(MapColor.COLOR_GREEN)));
    public static final RegistryObject<Block> GUMMY_BLUE = reg("gummy_blue", () -> new GummyBlock(gummy(MapColor.COLOR_BLUE)));

    // --- casita de corazon
    public static final RegistryObject<Block> CANDY_BRICK = reg("candy_brick",
            () -> new Block(solid(MapColor.COLOR_PINK, 1.5F, SoundType.STONE)));
    public static final RegistryObject<Block> STRAWBERRY_BLOCK = reg("strawberry_block",
            () -> new Block(solid(MapColor.COLOR_RED, 1.0F, SoundType.CORAL_BLOCK)));
    public static final RegistryObject<Block> SUGAR_BLOCK = reg("sugar_block",
            () -> new Block(solid(MapColor.SNOW, 0.5F, SoundType.SAND)));
    public static final RegistryObject<Block> CHOCOLATE_BLOCK = reg("chocolate_block",
            () -> new Block(solid(MapColor.COLOR_BROWN, 1.5F, SoundType.STONE)));
}
