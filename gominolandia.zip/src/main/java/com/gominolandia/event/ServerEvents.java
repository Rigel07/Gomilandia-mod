package com.gominolandia.event;

import com.gominolandia.GominolandiaMod;
import com.gominolandia.world.CandyData;
import com.gominolandia.world.CandyGenerator;
import com.mojang.logging.LogUtils;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

@Mod.EventBusSubscriber(modid = GominolandiaMod.MOD_ID)
public class ServerEvents {
    private static final Logger LOGGER = LogUtils.getLogger();

    /** Mundo NUEVO (aun no ha avanzado ni un tick): se genera el bosque y se mueve el spawn. */
    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        MinecraftServer server = event.getServer();
        ServerLevel overworld = server.overworld();
        CandyData data = CandyData.get(overworld);
        if (data.isGenerated()) return;
        if (overworld.getGameTime() > 20L) return; // mundo ya existente: no se toca (usa /gominolandia generar)
        try {
            BlockPos spawn = CandyGenerator.generate(overworld, overworld.getSharedSpawnPos());
            data.markGenerated(spawn);
        } catch (Exception e) {
            LOGGER.error("[Gominolandia] Fallo al generar el bosque", e);
        }
    }

    /** /gominolandia generar -> crea el bosque alrededor de ti (y mueve el spawn del mundo). */
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("gominolandia")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("generar").executes(ctx -> {
                    CommandSourceStack src = ctx.getSource();
                    ServerPlayer p = src.getPlayerOrException();
                    if (p.level().dimension() != Level.OVERWORLD) {
                        src.sendFailure(Component.literal("Solo funciona en el Overworld."));
                        return 0;
                    }
                    src.sendSuccess(() -> Component.literal("Generando el bosque de gominola (puede tardar unos segundos)..."), false);
                    ServerLevel level = p.serverLevel();
                    BlockPos spawn = CandyGenerator.generate(level, p.blockPosition());
                    CandyData.get(src.getServer().overworld()).markGenerated(spawn);
                    p.teleportTo(spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5);
                    src.sendSuccess(() -> Component.literal("¡Listo! Spawn del mundo movido a la casita de corazon."), true);
                    return 1;
                })));
    }
}
