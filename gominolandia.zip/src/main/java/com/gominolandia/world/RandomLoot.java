package com.gominolandia.world;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Botin totalmente aleatorio: cualquier objeto registrado (Minecraft + todos los mods instalados). */
public class RandomLoot {

    // ======== AJUSTES ========
    /** true = excluye objetos de administrador/rotos (bloques de comandos, barrier...). false = TODO. */
    public static final boolean EXCLUDE_ADMIN_ITEMS = true;
    /** Maximo de unidades por casilla (los objetos no apilables siempre salen de 1). */
    public static final int MAX_COUNT = 16;
    /** Casillas con objeto en cada cofre: MIN..MAX. */
    public static final int MIN_STACKS = 10;
    public static final int MAX_STACKS = 17;

    private static final Set<String> ADMIN_ITEMS = Set.of(
            "minecraft:air", "minecraft:command_block", "minecraft:chain_command_block",
            "minecraft:repeating_command_block", "minecraft:command_block_minecart",
            "minecraft:barrier", "minecraft:light", "minecraft:structure_block",
            "minecraft:structure_void", "minecraft:jigsaw", "minecraft:debug_stick",
            "minecraft:knowledge_book", "minecraft:bedrock");

    public static List<Item> buildPool() {
        List<Item> pool = new ArrayList<>();
        for (Map.Entry<net.minecraft.resources.ResourceKey<Item>, Item> e : ForgeRegistries.ITEMS.getEntries()) {
            Item item = e.getValue();
            if (item == Items.AIR) continue;
            ResourceLocation id = e.getKey().location();
            if (EXCLUDE_ADMIN_ITEMS && ADMIN_ITEMS.contains(id.toString())) continue;
            pool.add(item);
        }
        return pool;
    }

    public static void fill(Container chest, RandomSource random, List<Item> pool) {
        if (pool.isEmpty()) return;
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < chest.getContainerSize(); i++) slots.add(i);
        Collections.shuffle(slots, new java.util.Random(random.nextLong()));
        int n = Math.min(slots.size(), MIN_STACKS + random.nextInt(MAX_STACKS - MIN_STACKS + 1));
        for (int i = 0; i < n; i++) {
            Item item = pool.get(random.nextInt(pool.size()));
            int max = Math.max(1, item.getMaxStackSize());
            int count = 1 + random.nextInt(Math.min(max, MAX_COUNT));
            chest.setItem(slots.get(i), new ItemStack(item, count));
        }
        chest.setChanged();
    }
}
