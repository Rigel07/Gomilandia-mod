package com.gominolandia.world;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

/** Recuerda si ya se genero el bosque en este mundo (para no repetirlo). */
public class CandyData extends SavedData {
    private boolean generated = false;
    @Nullable
    private BlockPos spawn = null;

    public static CandyData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(CandyData::load, CandyData::new, "gominolandia");
    }

    public static CandyData load(CompoundTag tag) {
        CandyData d = new CandyData();
        d.generated = tag.getBoolean("Generated");
        if (tag.contains("SpawnX")) {
            d.spawn = new BlockPos(tag.getInt("SpawnX"), tag.getInt("SpawnY"), tag.getInt("SpawnZ"));
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Generated", generated);
        if (spawn != null) {
            tag.putInt("SpawnX", spawn.getX());
            tag.putInt("SpawnY", spawn.getY());
            tag.putInt("SpawnZ", spawn.getZ());
        }
        return tag;
    }

    public boolean isGenerated() { return generated; }

    public void markGenerated(BlockPos spawn) {
        this.generated = true;
        this.spawn = spawn;
        this.setDirty();
    }
}
