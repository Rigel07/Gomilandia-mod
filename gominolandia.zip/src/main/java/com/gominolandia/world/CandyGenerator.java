package com.gominolandia.world;

import com.gominolandia.block.ModBlocks;
import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Genera el bosque de gominola (radio ~70) con arboles de algodon de azucar, piruletas, gominolas
 * y una casita con forma de corazon con dos cofres de botin aleatorio. Devuelve el punto de aparicion.
 */
public class CandyGenerator {
    private static final Logger LOGGER = LogUtils.getLogger();

    // ======== AJUSTES ========
    public static final int RADIUS = 70;            // extension del bosque (bloques)
    private static final int PLATFORM = 17;         // explanada plana alrededor de la casa
    private static final int BLEND = 8;             // transicion explanada -> terreno
    private static final float TREE_CHANCE = 0.018F;
    private static final float LOLLIPOP_CHANCE = 0.0035F;
    private static final float BOULDER_CHANCE = 0.006F;
    private static final int HOUSE_W = 21;
    private static final int HOUSE_H = 19;
    private static final int WALL_H = 4;
    // =========================

    private static final int NO_GROUND = Integer.MIN_VALUE;
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    // ------------------------------------------------------------------ utilidades
    private static void set(ServerLevel level, int x, int y, int z, BlockState state) {
        level.setBlock(new BlockPos(x, y, z), state, FLAGS);
    }

    private static void setIfAir(ServerLevel level, int x, int y, int z, BlockState state) {
        BlockPos p = new BlockPos(x, y, z);
        if (level.getBlockState(p).isAir()) level.setBlock(p, state, FLAGS);
    }

    private static BlockState st(net.minecraftforge.registries.RegistryObject<Block> b) {
        return b.get().defaultBlockState();
    }

    private static double edgeRadius(int dx, int dz) {
        double a = Math.atan2(dz, dx);
        return RADIUS - 5 + 3 * Math.sin(3 * a + 1.3) + 2 * Math.sin(7 * a + 0.4);
    }

    private static double platformWeight(double dist) {
        if (dist <= PLATFORM) return 1.0;
        if (dist >= PLATFORM + BLEND) return 0.0;
        double s = (dist - PLATFORM) / BLEND;
        return 1.0 - s * s * (3 - 2 * s);
    }

    private static int findGround(ServerLevel level, int x, int z, int top) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int min = level.getMinBuildHeight();
        for (int y = top; y > min; y--) {
            p.set(x, y, z);
            BlockState s = level.getBlockState(p);
            if (!s.getFluidState().isEmpty()) return NO_GROUND;
            if (s.isAir() || s.is(BlockTags.LEAVES) || s.is(BlockTags.LOGS)
                    || s.getCollisionShape(level, p).isEmpty()) continue;
            return y;
        }
        return NO_GROUND;
    }

    // ------------------------------------------------------------------ principal
    public static BlockPos generate(ServerLevel level, BlockPos origin) {
        long t0 = System.currentTimeMillis();
        RandomSource rnd = RandomSource.create(level.getSeed() ^ 0x6A09E667F3BCC909L);
        int cx = origin.getX(), cz = origin.getZ();
        int area = RADIUS + 2;
        int size = area * 2 + 1;
        int ox = cx - area, oz = cz - area;

        // 1) cargar/generar todos los chunks de la zona
        int pad = 20;
        for (int chx = (cx - area - pad) >> 4; chx <= (cx + area + pad) >> 4; chx++) {
            for (int chz = (cz - area - pad) >> 4; chz <= (cz + area + pad) >> 4; chz++) {
                level.getChunk(chx, chz);
            }
        }

        // 2) medir el terreno original
        int[][] ground = new int[size][size];
        int[][] topY = new int[size][size];
        int[][] floorY = new int[size][size];
        boolean[][] water = new boolean[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                int x = ox + i, z = oz + j;
                int top = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;
                topY[i][j] = top;
                floorY[i][j] = level.getHeight(Heightmap.Types.OCEAN_FLOOR, x, z) - 1;
                water[i][j] = !level.getBlockState(new BlockPos(x, top, z)).getFluidState().isEmpty();
                ground[i][j] = water[i][j] ? NO_GROUND : findGround(level, x, z, top);
            }
        }

        // altura de la explanada de la casa = mediana del terreno central
        List<Integer> centerH = new ArrayList<>();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                int g = ground[area + dx][area + dz];
                if (g != NO_GROUND) centerH.add(g);
            }
        }
        int hc;
        if (centerH.isEmpty()) {
            hc = level.getSeaLevel();
        } else {
            Collections.sort(centerH);
            hc = centerH.get(centerH.size() / 2);
        }
        hc = Mth.clamp(hc, level.getMinBuildHeight() + 8, level.getMaxBuildHeight() - 50);

        BlockState grass = st(ModBlocks.GUMMY_GRASS);
        BlockState dirt = st(ModBlocks.CARAMEL_DIRT);
        BlockState air = Blocks.AIR.defaultBlockState();

        // 3) terreno: hierba de gominola + tierra de caramelo, limpiando la vegetacion
        int[][] finalGround = new int[size][size];
        for (int[] row : finalGround) Arrays.fill(row, NO_GROUND);

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                int dx = i - area, dz = j - area;
                double dist = Math.sqrt((double) dx * dx + (double) dz * dz);
                if (dist > edgeRadius(dx, dz)) continue;

                int x = ox + i, z = oz + j;
                double t = platformWeight(dist);
                boolean isWater = water[i][j];
                int base;
                int tgt;
                if (isWater) {
                    if (t < 0.5) continue;          // los lagos fuera de la explanada se quedan
                    base = floorY[i][j];
                    tgt = hc;
                } else {
                    base = ground[i][j];
                    if (base == NO_GROUND) continue;
                    tgt = t > 0 ? (int) Math.round(Mth.lerp(t, base, hc)) : base;
                }

                int top = topY[i][j];
                for (int y = tgt + 1; y <= top; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (!level.getBlockState(p).isAir()) level.setBlock(p, air, FLAGS);
                }
                for (int y = base + 1; y <= tgt; y++) set(level, x, y, z, dirt);
                set(level, x, tgt, z, grass);
                for (int y = tgt - 1; y >= tgt - 3; y--) {
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState cur = level.getBlockState(p);
                    if (!cur.isAir() && cur.getFluidState().isEmpty()) level.setBlock(p, dirt, FLAGS);
                }
                finalGround[i][j] = tgt;
            }
        }

        // 4) decoracion: arboles de algodon de azucar, piruletas y gominolas
        boolean[][] occ = new boolean[size][size];
        int trees = 0, lollipops = 0, boulders = 0;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                int g = finalGround[i][j];
                if (g == NO_GROUND) continue;
                int dx = i - area, dz = j - area;
                double dist = Math.sqrt((double) dx * dx + (double) dz * dz);
                if (dist < PLATFORM + BLEND - 2) continue;
                int x = ox + i, z = oz + j;
                float roll = rnd.nextFloat();
                if (roll < TREE_CHANCE) {
                    if (isFree(occ, i, j, 4)) {
                        cottonCandyTree(level, rnd, x, g, z);
                        mark(occ, i, j, 4);
                        trees++;
                    }
                } else if (roll < TREE_CHANCE + LOLLIPOP_CHANCE) {
                    if (isFree(occ, i, j, 3)) {
                        lollipop(level, rnd, x, g, z);
                        mark(occ, i, j, 3);
                        lollipops++;
                    }
                } else if (roll < TREE_CHANCE + LOLLIPOP_CHANCE + BOULDER_CHANCE) {
                    if (isFree(occ, i, j, 3)) {
                        gummyBoulder(level, rnd, x, g, z);
                        mark(occ, i, j, 3);
                        boulders++;
                    }
                }
            }
        }

        // 5) la casita de corazon + camino + piruletas-farola
        BlockPos spawn = buildHouse(level, rnd, cx, cz, hc);

        // 6) punto de aparicion del mundo
        level.setDefaultSpawnPos(spawn, 0.0F);
        level.getServer().getGameRules().getRule(GameRules.RULE_SPAWN_RADIUS).set(3, level.getServer());

        LOGGER.info("[Gominolandia] Bosque generado en {}ms: {} arboles, {} piruletas, {} gominolas. Spawn: {}",
                System.currentTimeMillis() - t0, trees, lollipops, boulders, spawn);
        return spawn;
    }

    // ------------------------------------------------------------------ ocupacion
    private static boolean isFree(boolean[][] occ, int i, int j, int r) {
        for (int a = -r; a <= r; a++) {
            for (int b = -r; b <= r; b++) {
                int ii = i + a, jj = j + b;
                if (ii >= 0 && jj >= 0 && ii < occ.length && jj < occ[0].length && occ[ii][jj]) return false;
            }
        }
        return true;
    }

    private static void mark(boolean[][] occ, int i, int j, int r) {
        for (int a = -r; a <= r; a++) {
            for (int b = -r; b <= r; b++) {
                int ii = i + a, jj = j + b;
                if (ii >= 0 && jj >= 0 && ii < occ.length && jj < occ[0].length) occ[ii][jj] = true;
            }
        }
    }

    // ------------------------------------------------------------------ decoracion
    private static BlockState leavesColor(int k) {
        return switch (Math.floorMod(k, 3)) {
            case 0 -> st(ModBlocks.COTTON_CANDY_PINK);
            case 1 -> st(ModBlocks.COTTON_CANDY_BLUE);
            default -> st(ModBlocks.COTTON_CANDY_LILAC);
        };
    }

    private static BlockState gummyColor(int k) {
        return switch (Math.floorMod(k, 5)) {
            case 0 -> st(ModBlocks.GUMMY_RED);
            case 1 -> st(ModBlocks.GUMMY_ORANGE);
            case 2 -> st(ModBlocks.GUMMY_YELLOW);
            case 3 -> st(ModBlocks.GUMMY_GREEN);
            default -> st(ModBlocks.GUMMY_BLUE);
        };
    }

    private static void blob(ServerLevel level, RandomSource r, int cx, int cy, int cz, int rad, BlockState state) {
        for (int dx = -rad; dx <= rad; dx++) {
            for (int dy = -rad; dy <= rad; dy++) {
                for (int dz = -rad; dz <= rad; dz++) {
                    double d = dx * dx + dy * dy * 1.3 + dz * dz;
                    if (d <= rad * rad + r.nextInt(rad + 1)) setIfAir(level, cx + dx, cy + dy, cz + dz, state);
                }
            }
        }
    }

    /** Tronco de caramelo + nube de algodon de azucar. */
    private static void cottonCandyTree(ServerLevel level, RandomSource r, int x, int gy, int z) {
        int h = 5 + r.nextInt(4);
        BlockState log = st(ModBlocks.CANDY_LOG);
        for (int i = 1; i <= h; i++) set(level, x, gy + i, z, log);
        int roll = r.nextInt(10);
        int primary = roll < 5 ? 0 : (roll < 8 ? 1 : 2);
        int rad = 3 + r.nextInt(2);
        int cy = gy + h + 1;
        blob(level, r, x, cy, z, rad, leavesColor(primary));
        for (int k = 0; k < 3; k++) {
            int ax = x + r.nextInt(rad * 2 - 1) - (rad - 1);
            int ay = cy + r.nextInt(3) - 1;
            int az = z + r.nextInt(rad * 2 - 1) - (rad - 1);
            blob(level, r, ax, ay, az, rad - 1, leavesColor(r.nextInt(3) == 0 ? primary + 1 : primary));
        }
    }

    /** Piruleta: palo de azucar + cabeza de gominolas a dos colores. */
    private static void lollipop(ServerLevel level, RandomSource r, int x, int gy, int z) {
        int h = 3 + r.nextInt(3);
        BlockState stick = st(ModBlocks.SUGAR_BLOCK);
        for (int i = 1; i <= h; i++) set(level, x, gy + i, z, stick);
        BlockState a = gummyColor(r.nextInt(5)), b = gummyColor(r.nextInt(5));
        int cy = gy + h + 2;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (dx * dx + dy * dy + dz * dz <= 5) {
                        setIfAir(level, x + dx, cy + dy, z + dz, ((dx + dy + dz) & 1) == 0 ? a : b);
                    }
                }
            }
        }
    }

    /** Pequeno monton de gominolas. */
    private static void gummyBoulder(ServerLevel level, RandomSource r, int x, int gy, int z) {
        BlockState c = gummyColor(r.nextInt(5));
        int n = 2 + r.nextInt(4);
        for (int k = 0; k < n; k++) {
            int bx = x + r.nextInt(3) - 1, bz = z + r.nextInt(3) - 1;
            int hh = 1 + r.nextInt(2);
            for (int y = 1; y <= hh; y++) setIfAir(level, bx, gy + y, bz, c);
        }
    }

    // ------------------------------------------------------------------ casita de corazon
    private static boolean[][] heartMask(int w, int h) {
        boolean[][] m = new boolean[w][h];
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                double x = ((i + 0.5) / w * 2 - 1) * 1.16;
                double y = 1.28 - ((j + 0.5) / h) * 2.29;
                double a = x * x + y * y - 1;
                m[i][j] = a * a * a - x * x * y * y * y <= 0;
            }
        }
        return m;
    }

    private static boolean[][] erode(boolean[][] m) {
        int w = m.length, h = m[0].length;
        boolean[][] o = new boolean[w][h];
        int[][] n4 = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                if (!m[i][j]) continue;
                boolean keep = true;
                for (int[] d : n4) {
                    int a = i + d[0], b = j + d[1];
                    if (a < 0 || b < 0 || a >= w || b >= h || !m[a][b]) { keep = false; break; }
                }
                o[i][j] = keep;
            }
        }
        return o;
    }

    private static boolean any(boolean[][] m) {
        for (boolean[] row : m) for (boolean b : row) if (b) return true;
        return false;
    }

    /** Celda interior mas cercana a (ti,tj). */
    private static int[] nearestInterior(boolean[][] interior, int ti, int tj) {
        int[] best = null;
        double bd = Double.MAX_VALUE;
        for (int i = 0; i < interior.length; i++) {
            for (int j = 0; j < interior[0].length; j++) {
                if (!interior[i][j]) continue;
                double d = (i - ti) * (i - ti) + (j - tj) * (j - tj);
                if (d < bd) { bd = d; best = new int[]{i, j}; }
            }
        }
        return best;
    }

    private static BlockPos buildHouse(ServerLevel level, RandomSource rnd, int hx, int hz, int h) {
        boolean[][] m0 = heartMask(HOUSE_W, HOUSE_H);
        boolean[][] m1 = erode(m0);
        int x0 = hx - HOUSE_W / 2, z0 = hz - HOUSE_H / 2;
        int ci = HOUSE_W / 2;

        BlockState sugar = st(ModBlocks.SUGAR_BLOCK);
        BlockState brick = st(ModBlocks.CANDY_BRICK);
        BlockState straw = st(ModBlocks.STRAWBERRY_BLOCK);
        BlockState choco = st(ModBlocks.CHOCOLATE_BLOCK);
        BlockState glass = Blocks.PINK_STAINED_GLASS.defaultBlockState();
        BlockState carpet = Blocks.PINK_CARPET.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();

        // suelo, paredes, techo plano
        for (int i = 0; i < HOUSE_W; i++) {
            for (int j = 0; j < HOUSE_H; j++) {
                if (!m0[i][j]) continue;
                int x = x0 + i, z = z0 + j;
                set(level, x, h, z, sugar);
                boolean wall = !m1[i][j];
                if (wall) {
                    boolean window = j < HOUSE_H - 4 && Math.abs(i - ci) > 1 && (i * 7 + j * 3) % 6 == 0;
                    for (int y = 1; y <= WALL_H; y++) {
                        BlockState b;
                        if (y == 1) b = choco;
                        else if (y == WALL_H) b = straw;
                        else b = window ? glass : brick;
                        set(level, x, h + y, z, b);
                    }
                } else {
                    set(level, x, h + 1, z, carpet);
                }
                set(level, x, h + WALL_H + 1, z, brick); // techo
            }
        }

        // tejado: heart-shaped escalonado (capas cada vez mas pequenas)
        boolean[][] cur = m1;
        int k = 1;
        while (any(cur)) {
            BlockState b = (k % 2 == 1) ? straw : brick;
            for (int i = 0; i < HOUSE_W; i++) {
                for (int j = 0; j < HOUSE_H; j++) {
                    if (cur[i][j]) set(level, x0 + i, h + WALL_H + 1 + k, z0 + j, b);
                }
            }
            cur = erode(cur);
            k++;
        }

        // puerta: la punta sur del corazon
        int tip = 0;
        for (int j = 0; j < HOUSE_H; j++) if (m0[ci][j]) tip = j;
        for (int j = tip; j >= 0; j--) {
            if (m1[ci][j]) break;
            set(level, x0 + ci, h + 1, z0 + j, air);
            set(level, x0 + ci, h + 2, z0 + j, air);
        }
        int tipZ = z0 + tip;

        // mobiliario
        boolean[][] interior = m1;
        int jc = HOUSE_H / 2 - 1;
        int[] c1 = nearestInterior(interior, ci - 3, jc);
        int[] c2 = nearestInterior(interior, ci + 3, jc);
        int[] cake = nearestInterior(interior, ci, jc);
        if (cake != null) {
            set(level, x0 + cake[0], h + 1, z0 + cake[1], choco);
            set(level, x0 + cake[0], h + 2, z0 + cake[1], Blocks.CAKE.defaultBlockState());
        }
        List<Item> pool = RandomLoot.buildPool();
        for (int[] c : new int[][]{c1, c2}) {
            if (c == null) continue;
            BlockPos cp = new BlockPos(x0 + c[0], h + 1, z0 + c[1]);
            level.setBlock(cp, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.SOUTH), FLAGS);
            BlockEntity be = level.getBlockEntity(cp);
            if (be instanceof Container container) RandomLoot.fill(container, rnd, pool);
        }
        BlockState lantern = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
        int[][] lanternSpots = {{ci - 5, jc - 2}, {ci + 5, jc - 2}, {ci - 4, jc + 3}, {ci + 4, jc + 3}, {ci, jc - 4}};
        for (int[] ls : lanternSpots) {
            int a = ls[0], b = ls[1];
            if (a >= 0 && b >= 0 && a < HOUSE_W && b < HOUSE_H && interior[a][b]) {
                set(level, x0 + a, h + WALL_H, z0 + b, lantern);
            }
        }

        // camino de azucar hacia el sur + piruletas-farola de caramelo
        int spawnZ = tipZ + 6;
        for (int z = tipZ + 1; z <= spawnZ + 4; z++) {
            for (int dx = -1; dx <= 1; dx++) set(level, x0 + ci + dx, h, z, sugar);
        }
        BlockState glow = Blocks.GLOWSTONE.defaultBlockState();
        for (int z = tipZ + 3; z <= spawnZ + 3; z += 5) {
            for (int side : new int[]{-3, 3}) {
                int lx = x0 + ci + side;
                for (int y = 1; y <= 3; y++) set(level, lx, h + y, z, sugar);
                set(level, lx, h + 4, z, glow);
            }
        }
        return new BlockPos(x0 + ci, h + 1, spawnZ);
    }
}
