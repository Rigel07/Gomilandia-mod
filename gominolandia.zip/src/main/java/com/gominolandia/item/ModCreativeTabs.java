package com.gominolandia.item;

import com.gominolandia.GominolandiaMod;
import com.gominolandia.block.ModBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GominolandiaMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + GominolandiaMod.MOD_ID))
                    .icon(() -> new ItemStack(ModBlocks.COTTON_CANDY_PINK.get()))
                    .displayItems((params, output) ->
                            ModBlocks.ALL.forEach(b -> output.accept(b.get())))
                    .build());
}
