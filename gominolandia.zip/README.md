# Gominolandia (Forge 1.20.1)

Al crear un mundo NUEVO apareces en un **bosque de gominola** (radio ~70 bloques) con árboles de algodón de
azúcar, piruletas gigantes, montones de gominolas y una **casita con forma de corazón** con **dos cofres**
de botín **completamente aleatorio** (cualquier objeto de Minecraft y de todos los mods instalados).

## Cómo funciona
- Al arrancar un mundo recién creado, el mod genera el bosque alrededor del spawn y mueve el spawn
  a la entrada de la casita (la "punta" del corazón). El spawn exacto queda en un camino de azúcar.
- Mundos ya existentes NO se tocan. Para crearlo en uno existente (op): `/gominolandia generar`
  (crea el bosque alrededor de ti y mueve el spawn del mundo).
- Ajusta `spawnRadius` a 3 (el mod lo pone) para que todos aparezcan junto a la casa.

## Ajustes (en el código)
- `world/CandyGenerator.java`: RADIUS (tamaño), densidad de árboles/piruletas/gominolas, tamaño de la casa.
- `world/RandomLoot.java`: EXCLUDE_ADMIN_ITEMS (false = absolutamente TODO), MAX_COUNT, nº de casillas.

## Bloques nuevos
Hierba de gominola, tierra de caramelo, tronco de caramelo, algodón de azúcar (rosa/azul/lila),
gominolas (rojo/naranja/amarillo/verde/azul; amortiguan caídas), ladrillo de caramelo, bloque de fresa,
bloque de azúcar y bloque de chocolate. Todo en la pestaña creativa "Gominolandia".

## Compilar en GitHub
Sube el .zip (o su contenido) al repo con `.github/workflows/build.yml` -> Actions -> el .jar sale en Releases/Artifacts.
